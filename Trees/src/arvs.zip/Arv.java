/*
NOMES:
HENRIQUE VIEIRA LIMA    NUSP: 15459372
GABRIEL PHILIPPE PRADO  NUSP: 15453730

*/

public interface Arv {
    public boolean find(String var1);
    public void insert(String value);
    public int len();
    public boolean remove(String target);
    public String toString();
}
